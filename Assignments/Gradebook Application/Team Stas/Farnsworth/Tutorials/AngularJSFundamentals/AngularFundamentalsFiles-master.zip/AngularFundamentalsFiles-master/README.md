Angular Fundamentals Course
========================

The course is up to Date.

You may have some difficulty in the testing module when following along the section on end to end testing. A further update using Angular's new end to end testing tool Protractor is forthcoming.
